<?php defined ('_JEXEC') or die('Restricted access'); ?>
<h1><?= $this->msg; ?></h1>
