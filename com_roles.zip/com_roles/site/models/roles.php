<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.modelitem');

class RolesModelRoles extends JModelItem
{
    
}