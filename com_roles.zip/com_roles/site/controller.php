<?php
defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class RolesController extends JControllerLegacy
{
    
}

