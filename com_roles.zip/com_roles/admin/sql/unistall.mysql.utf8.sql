DROP TABLE IF EXISTS `#__roles_info`;
DROP TABLE IF EXISTS `#__roles_user`;
DROP TABLE IF EXISTS `#__roles_role`;
DROP TABLE IF EXISTS `#__roles_categories`;
