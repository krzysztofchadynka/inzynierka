DROP TABLE IF EXISTS `#__roles_user`;
DROP TABLE IF EXISTS `#__roles_role`;
DROP TABLE IF EXISTS `#__roles_rule`;
DROP TABLE IF EXISTS `#__roles_role_rule`;
