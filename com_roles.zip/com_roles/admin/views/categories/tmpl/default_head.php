<?php
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
    <th><?= JHtml::_('grid.checkall'); ?></th>
    <th><?= JText::_('COM_ROLES_CATEGORIES_HEADING_ROLE_NAME'); ?></th>
    <th><?= JText::_('COM_ROLES_CATEGORIES_HEADING_CATEGORY_NAME'); ?></th>
</tr>