<?php
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
    <th width="20"><?= JHtml::_('grid.checkall'); ?></th>
    <th><?= JText::_('COM_ROLES_CATEGORY_HEADING_ROLE'); ?></th>
    <th width="5"><?= JText::_('COM_ROLES_CATEGORY_HEADING_CATEGORY'); ?></th>
</tr>