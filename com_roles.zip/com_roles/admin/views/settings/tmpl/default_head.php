<?php defined('_JEXEC') or die('Restricted Access'); ?>
<tr>
    <th><?= JHtml::_('grid.checkall'); ?></th>
    <th></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_HEADER'); ?></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_DESC'); ?></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_IMAGE'); ?></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_USER_INFO'); ?></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_ROLE_INFO'); ?></th>
    <th><?= JText::_('COM_ROLES_SETTINGS_HEADING_CATEGORIES_INFO'); ?></th>
</tr>

