<?php
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
    <td colspan="3"><?= $this->pagination->getListFooter(); ?></td>
</tr>