<?php defined ('_JEXEC') or die('Restricted access'); ?>

<tr>
    <td colspan="3"><?= $this->pagination->getListFooter(); ?></td>
</tr>