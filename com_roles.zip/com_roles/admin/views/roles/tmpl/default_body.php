<?php defined ('_JEXEC') or die('Restricted access'); ?>

<?php foreach ($this->items as $i => $item): ?>
    <tr class="row<?= $i % 2; ?>">
        
    </tr>
<?php endforeach; ?>
