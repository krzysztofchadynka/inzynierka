<?php defined ('_JEXEC') or die('Restricted access'); ?>

<tr>
    <th width="20"><?= JHtml::_('grid.checkall'); ?></th>
    <th><?= JText::_('COM_ROLES_HEADING_ROLE_ID'); ?></th>
    <th><?= JText::_('COM_ROLES_HEADING_ROLE_NAME'); ?></th>
</tr>
