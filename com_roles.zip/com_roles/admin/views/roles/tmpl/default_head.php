<?php defined ('_JEXEC') or die('Restricted access'); ?>

<tr>
    <th width="20"><?= JHtml::_('grid.checkall'); ?></th>
    <th><?= JText::_('COM_ROLES_ROLES_HEADING_GREETING'); ?></th>
    <th width="5"><?= JText::_('COM_ROLES_ROLES_HEADING_ID'); ?></th>
</tr>