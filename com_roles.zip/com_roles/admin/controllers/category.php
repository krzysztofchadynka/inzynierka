<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class RolesControllerCategory extends JControllerForm
{
    
}