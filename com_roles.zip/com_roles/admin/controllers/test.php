<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');
 
class RolesControllerTest extends JControllerForm
{
}